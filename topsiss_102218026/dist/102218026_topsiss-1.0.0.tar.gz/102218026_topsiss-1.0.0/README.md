# Upper-case-change
ranking according to your preferances
## Installation
```pip install topsiss_102218026```

## How to use it?
enter the value of weights and sign of impact 
range of weight is in 0 to 1
imapct must be '+','-'
## License

© 2020 shubham aggarwal

This repository is licensed under the MIT license. See LICENSE for details.